package edu.northwestern.bioinformatics.studycalendar.domain;

/**
 * @author Rhett Sutphin
 */
public interface Named {
    String getName();
    void setName(String name);
}
