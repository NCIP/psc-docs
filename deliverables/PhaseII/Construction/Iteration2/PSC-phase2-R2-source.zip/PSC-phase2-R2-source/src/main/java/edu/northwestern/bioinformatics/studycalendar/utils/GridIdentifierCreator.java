package edu.northwestern.bioinformatics.studycalendar.utils;

/**
 * @author Rhett Sutphin
 */
public interface GridIdentifierCreator {
    String getGridIdentifier();
}
