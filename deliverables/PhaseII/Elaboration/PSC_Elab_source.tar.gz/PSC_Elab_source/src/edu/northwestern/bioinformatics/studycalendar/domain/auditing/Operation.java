package edu.northwestern.bioinformatics.studycalendar.domain.auditing;

/**
 * @author Rhett Sutphin
 */
public enum Operation {
    CREATE, UPDATE, DELETE
}
