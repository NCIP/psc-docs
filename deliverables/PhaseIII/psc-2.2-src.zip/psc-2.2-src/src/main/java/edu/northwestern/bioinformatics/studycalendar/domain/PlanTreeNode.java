package edu.northwestern.bioinformatics.studycalendar.domain;

import gov.nih.nci.cabig.ctms.domain.AbstractMutableDomainObject;
import gov.nih.nci.cabig.ctms.domain.DomainObject;
import edu.northwestern.bioinformatics.studycalendar.StudyCalendarError;

/**
 * @author Rhett Sutphin
 * @param <P> parent class
 */
public abstract class PlanTreeNode<P extends DomainObject> extends AbstractMutableDomainObject
    implements Child<P>, Cloneable, TransientCloneable<PlanTreeNode<P>>
{
    private P parent;
    private boolean memoryOnly;

    ////// LOGIC

    /**
     * Returns true if the segment of the plan tree to which this node belongs
     * is not directly associated with a study.  (That is, it is part of an unapplied revision.)
     * @return
     */
    public boolean isDetached() {
        if (getParent() == null) {
            return true;
        } else if (getParent() instanceof PlanTreeNode) {
            return ((PlanTreeNode) getParent()).isDetached();
        } else {
            return false;
        }
    }

    public void clearIds() {
        setId(null);
        setGridId(null);
    }

    ////// Child IMPLEMENTATION

    public abstract Class<P> parentClass();

    public P getParent() {
        return parent;
    }

    public void setParent(P parent) {
        this.parent = parent;
    }

    ////// TransientCloneable IMPLEMENTATION

    public boolean isMemoryOnly() {
        return memoryOnly;
    }

    public void setMemoryOnly(boolean memoryOnly) {
        this.memoryOnly = memoryOnly;
    }

    public PlanTreeNode<P> transientClone() {
        PlanTreeNode<P> clone = this.clone();
        clone.setMemoryOnly(true);
        return clone;
    }

    ////// OBJECT METHODS

    @Override
    @SuppressWarnings({ "unchecked" })
    protected PlanTreeNode<P> clone() {
        try {
            return (PlanTreeNode<P>) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new StudyCalendarError("Clone is supported", e);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(getClass().getSimpleName())
            .append("[id=").append(getId());
        if (isMemoryOnly()) sb.append("; transient copy");
        sb.append(']');
        return sb.toString();
    }
}
