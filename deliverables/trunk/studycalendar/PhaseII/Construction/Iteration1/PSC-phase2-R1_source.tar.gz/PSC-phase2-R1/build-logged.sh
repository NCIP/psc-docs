#!/bin/sh

{
. build.sh
} > build.run 2>&1
