package edu.northwestern.bioinformatics.studycalendar.web;

import org.springframework.web.servlet.mvc.ParameterizableViewController;

/**
 * This is dummy code that I expect someone to delete.
 *
 * @author Moses Hohman
 */
public class WelcomeController extends ParameterizableViewController {
    public WelcomeController() {
        setViewName("welcome");
    }
}
