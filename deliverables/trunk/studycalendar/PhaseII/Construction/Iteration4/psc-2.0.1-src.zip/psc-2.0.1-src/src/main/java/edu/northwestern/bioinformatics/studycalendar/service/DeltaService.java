package edu.northwestern.bioinformatics.studycalendar.service;

import edu.northwestern.bioinformatics.studycalendar.StudyCalendarSystemException;
import edu.northwestern.bioinformatics.studycalendar.dao.DaoFinder;
import edu.northwestern.bioinformatics.studycalendar.dao.DeletableDomainObjectDao;
import edu.northwestern.bioinformatics.studycalendar.dao.delta.DeltaDao;
import edu.northwestern.bioinformatics.studycalendar.dao.delta.ChangeDao;
import edu.northwestern.bioinformatics.studycalendar.domain.PlanTreeInnerNode;
import edu.northwestern.bioinformatics.studycalendar.domain.PlanTreeNode;
import edu.northwestern.bioinformatics.studycalendar.domain.Study;
import edu.northwestern.bioinformatics.studycalendar.domain.PlannedCalendar;
import edu.northwestern.bioinformatics.studycalendar.domain.ScheduledCalendar;
import edu.northwestern.bioinformatics.studycalendar.domain.StudySubjectAssignment;
import edu.northwestern.bioinformatics.studycalendar.domain.delta.Add;
import edu.northwestern.bioinformatics.studycalendar.domain.delta.Change;
import edu.northwestern.bioinformatics.studycalendar.domain.delta.ChangeAction;
import edu.northwestern.bioinformatics.studycalendar.domain.delta.Delta;
import edu.northwestern.bioinformatics.studycalendar.domain.delta.Revision;
import edu.northwestern.bioinformatics.studycalendar.domain.delta.Amendment;
import edu.northwestern.bioinformatics.studycalendar.domain.delta.ChildrenChange;
import edu.northwestern.bioinformatics.studycalendar.service.delta.MutatorFactory;
import edu.northwestern.bioinformatics.studycalendar.service.delta.Mutator;
import gov.nih.nci.cabig.ctms.dao.DomainObjectDao;
import gov.nih.nci.cabig.ctms.dao.MutableDomainObjectDao;
import gov.nih.nci.cabig.ctms.domain.MutableDomainObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.restlet.resource.Resource;

import java.util.List;
import java.util.ArrayList;

/**
 * Provides methods for calculating deltas and for applying them to PlannedCalendars.
 * Also provides maintenance methods for deltas.
 *
 * @author Rhett Sutphin
 */
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class DeltaService {
    private final Logger log = LoggerFactory.getLogger(getClass());
    private MutatorFactory mutatorFactory;
    private DaoFinder daoFinder;
    private DeltaDao deltaDao;
    private ChangeDao changeDao;
    private TemplateService templateService;

    /**
     * Applies all the deltas in the given revision to the source study,
     * returning a new, transient Study.  The revision might be
     * and in-progress amendment or a customization.
     */
    public Study revise(Study source, Revision revision) {
        log.debug("Revising {} with {}", source, revision);
        Study revised = source.transientClone();
        apply(revised, revision);
        return revised;
    }

    /**
     * Applies the given amendment to the calendar for the subject in the
     * given assignment.
     */
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void amend(StudySubjectAssignment assignment, Amendment amendment) {
        if (!assignment.getStudySite().getStudy().getAmendmentsList().contains(amendment)) {
            throw new StudyCalendarSystemException("The amendment {} does not apply to assignment {}", amendment.getId(), assignment.getId());
        }
        if (assignment.getCurrentAmendment().equals(amendment.getPreviousAmendment())) {
            apply(assignment.getScheduledCalendar(), amendment);
            assignment.setCurrentAmendment(amendment);
        } else {
            amend(assignment, amendment.getPreviousAmendment());
            amend(assignment, amendment);
        }
    }

    public <T extends PlanTreeNode<?>> T revise(T source) {
        return revise(source, null);
    }

    @SuppressWarnings({ "unchecked" })
    public <T extends PlanTreeNode<?>> T revise(T source, Revision revision) {
        PlannedCalendar calendar;
        if (PlannedCalendar.class.isAssignableFrom(source.getClass())) {
            calendar = (PlannedCalendar) source;
        } else {
            calendar = templateService.findAncestor(source, PlannedCalendar.class);
        }

        if (revision == null) {
            revision = calendar.getStudy().getDevelopmentAmendment();
        }

        Study revised = revise(calendar.getStudy(), revision);
        return (T) templateService.findEquivalentChild(revised.getPlannedCalendar(), source);
    }

    /**
     * Applies all the deltas in the given revision directly to the given study.
     */
    public void apply(Study target, Revision revision) {
        log.debug("Applying {} to {}", revision, target);
        for (Delta<?> delta : revision.getDeltas()) {
            PlanTreeNode<?> affected = findNodeForDelta(target, delta);
            for (Change change : delta.getChanges()) {
                log.debug("Applying change {} on {}", change, affected);
                mutatorFactory.createMutator(affected, change).apply(affected);
            }
        }
    }

    public void revert(Study target, Revision revision) {
        log.debug("Reverting {} from {}", revision, target);
        for (Delta<?> delta : revision.getDeltas()) {
            PlanTreeNode<?> affected = findNodeForDelta(target, delta);
            for (Change change : delta.getChanges()) {
                log.debug("Rolling back change {} on {}", change, affected);
                mutatorFactory.createMutator(affected, change).revert(affected);
            }
        }
    }

    private void apply(ScheduledCalendar target, Revision revision) {
        log.debug("Applying {} to {}", revision, target);
        for (Delta<?> delta : revision.getDeltas()) {
            PlanTreeNode<?> affected = findNodeForDelta(target.getAssignment().getStudySite().getStudy(), delta);
            for (Change change : delta.getChanges()) {
                log.debug("Applying change {} on {}", change, affected);
                Mutator mutator = mutatorFactory.createMutator(affected, change);
                if (mutator.appliesToExistingSchedules()) {
                    mutator.apply(target);
                }
            }
        }
    }

    /**
     * Merge the change for the node into the target revision
     * @param target
     * @param node
     * @param change
     */
    @Transactional(propagation = Propagation.SUPPORTS)
    public void updateRevision(Revision target, PlanTreeNode<?> node, Change change) {
        log.debug("Updating {}", target);
        if (node.isDetached()) {
            log.debug("{} is detached; apply {} directly", node, change);
            mutateNode(node, change);
        } else {
            log.debug("{} is part of the live tree; track {} separately", node, change);
            Delta<?> existing = null;
            for (Delta<?> delta : target.getDeltas()) {
                if (templateService.isEquivalent(delta.getNode(), node)) {
                    existing = delta;
                    break;
                }
            }
            if (existing == null) {
                log.debug("  - this is the first change; create new delta", change, node);
                target.getDeltas().add(Delta.createDeltaFor(node, change));
            } else {
                log.debug("  - it has been changed before; merge into existing delta {}", existing);
                change.mergeInto(existing);
            }
        }
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void mutateNode(PlanTreeNode<?> node, Change change) {
        mutatorFactory.createMutator(node, change).apply(node);
    }

    private PlanTreeNode<?> findNodeForDelta(Study revised, Delta<?> delta) {
        PlanTreeNode<?> affected = templateService.findEquivalentChild(revised, delta.getNode());
        if (affected == null) {
            throw new StudyCalendarSystemException(
                "Could not find a node in the target study matching the node in %s", delta);
        }
        return affected;
    }

    public void saveRevision(Revision revision) {
        if (revision == null) {
            throw new NullPointerException("Can't save a null revision");
        }
        if (!(revision instanceof MutableDomainObject)) {
            throw new StudyCalendarSystemException("%s is not a MutableDomainObject",
                revision.getClass().getName());
        }
        findDaoAndSave((MutableDomainObject) revision);
        for (Delta<?> delta : revision.getDeltas()) {
            for (Change change : delta.getChanges()) {
                if (change.getAction() == ChangeAction.ADD) {
                    PlanTreeNode<?> child = ((Add) change).getChild();
                    if (child != null) {
                        findDaoAndSave(child);
                    }
                }
            }
            findDaoAndSave(delta.getNode());
            deltaDao.save(delta);
        }
    }

    private void findDaoAndSave(MutableDomainObject object) {
        DomainObjectDao<?> dao = daoFinder.findDao(object.getClass());
        if (!(dao instanceof MutableDomainObjectDao)) {
            throw new StudyCalendarSystemException("%s does not implement %s", dao.getClass().getName(),
                MutableDomainObjectDao.class.getName());
        }
        ((MutableDomainObjectDao) dao).save(object);
    }

    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(Delta<?> delta) {
        for (Change change : delta.getChanges()) {
            if (change.getAction() == ChangeAction.ADD) {
                Add add = ((Add) change);
                PlanTreeNode child = add.getChild();
                if (child == null) {
                    PlanTreeInnerNode node = (PlanTreeInnerNode) delta.getNode();
                    child = findDaoAndLoad(add.getChildId(), node.childClass());
                }
                templateService.delete(child);
            }
        }
        for (Change change : new ArrayList<Change>(delta.getChanges())) {
            delta.removeChange(change);
            changeDao.delete(change);
        }
        deltaDao.delete(delta);
    }

    @SuppressWarnings({ "unchecked" })
    private <T extends PlanTreeNode> T findDaoAndLoad(int id, Class<T> klass) {
        DomainObjectDao<T> dao = (DomainObjectDao<T>) daoFinder.findDao(klass);
        return dao.getById(id);
    }

    ////// CONFIGURATION

    @Required
    public void setMutatorFactory(MutatorFactory mutatorFactory) {
        this.mutatorFactory = mutatorFactory;
    }

    @Required
    public void setChangeDao(ChangeDao changeDao) {
        this.changeDao = changeDao;
    }

    @Required
    public void setDeltaDao(DeltaDao deltaDao) {
        this.deltaDao = deltaDao;
    }

    @Required
    public void setDaoFinder(DaoFinder daoFinder) {
        this.daoFinder = daoFinder;
    }

    @Required
    public void setTemplateService(TemplateService templateService) {
        this.templateService = templateService;
    }
}
