package edu.northwestern.bioinformatics.studycalendar.utils.breadcrumbs;

/**
 * @author Rhett Sutphin
 */
public interface CrumbSource {
    Crumb getCrumb();
}
