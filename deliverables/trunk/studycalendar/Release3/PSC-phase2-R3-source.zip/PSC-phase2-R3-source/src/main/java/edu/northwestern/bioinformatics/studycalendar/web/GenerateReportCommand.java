package edu.northwestern.bioinformatics.studycalendar.web;

/*
 * @author Yufang Wang
 */

public class GenerateReportCommand {
	
}
